import { default as colorConvert_1_0 } from './functions/colorConvert/1.0';
import { default as concatenateNames_1_0 } from './functions/concatenate-names/1.0';
import { default as fetchPokemon_1_0 } from './functions/fetchPokemon/1.0';
import { default as sayHello_1_0 } from './functions/say-hello/1.0';
import { default as sumCustom_1_0 } from './functions/sum-custom/1.0';
import { default as timeDifference_1_0 } from './functions/time-difference/1.0';

const fn = {
  "colorConvert 1.0": colorConvert_1_0,
  "concatenateNames 1.0": concatenateNames_1_0,
  "fetchPokemon 1.0": fetchPokemon_1_0,
  "sayHello 1.0": sayHello_1_0,
  "sumCustom 1.0": sumCustom_1_0,
  "timeDifference 1.0": timeDifference_1_0,
};

export default fn;
